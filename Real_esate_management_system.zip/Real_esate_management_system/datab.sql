create database final;
use final;


CREATE TABLE User (
    UserID INT PRIMARY KEY,
    Username VARCHAR(50) NOT NULL,
    PasswordHash VARCHAR(255) NOT NULL,
    Role VARCHAR(20) NOT NULL,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    ContactInformation VARCHAR(255)
);


CREATE TABLE Agent (
    AgentID INT PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    ContactInformation VARCHAR(255),
    LicenseNumber VARCHAR(20) NOT NULL,
    Specialization VARCHAR(100),
    UserID INT UNIQUE NOT NULL,
    FOREIGN KEY (UserID) REFERENCES User(UserID)
);


CREATE TABLE Client (
    ClientID INT PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    ContactInformation VARCHAR(255),
    PreferredPropertyType VARCHAR(50),
    Budget DECIMAL(10, 2),
    PreferredLocation VARCHAR(255)
);


CREATE TABLE Property (
    PropertyID INT PRIMARY KEY,
    Address VARCHAR(255) NOT NULL,
    PropertyType VARCHAR(50) NOT NULL,
    SquareFootage INT,
    Bedrooms INT,
    Bathrooms INT,
    ListingPrice DECIMAL(10, 2),
    Status VARCHAR(20) NOT NULL,
    AgentID INT,
    FOREIGN KEY (AgentID) REFERENCES Agent(AgentID)
);


CREATE TABLE Transaction (
    TransactionID INT PRIMARY KEY,
    PropertyID INT NOT NULL,
    ClientID INT NOT NULL,
    AgentID INT NOT NULL,
    TransactionType VARCHAR(20) NOT NULL,
    TransactionDate DATE NOT NULL,
    SalePrice DECIMAL(10, 2),
    RentalPrice DECIMAL(10, 2),
    FOREIGN KEY (PropertyID) REFERENCES Property(PropertyID),
    FOREIGN KEY (ClientID) REFERENCES Client(ClientID),
    FOREIGN KEY (AgentID) REFERENCES Agent(AgentID)
);

CREATE TABLE Appointment (
    AppointmentID INT PRIMARY KEY,
    ClientID INT NOT NULL,
    AgentID INT NOT NULL,
    PropertyID INT NOT NULL,
    AppointmentDateTime DATETIME NOT NULL,
    Status VARCHAR(20) NOT NULL,
    FOREIGN KEY (ClientID) REFERENCES Client(ClientID),
    FOREIGN KEY (AgentID) REFERENCES Agent(AgentID),
    FOREIGN KEY (PropertyID) REFERENCES Property(PropertyID)
);
