<?php
// Create connection to your database
$conn = new mysqli("localhost", "root", "no", "final");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get data from the form
    $clientIDToUpdate = $_POST['client-id-to-update'];
    $newFirstName = $_POST['new-first-name'];
    $newLastName = $_POST['new-last-name'];
    $newContactInfo = $_POST['new-contact-info'];
    $newPreferredPropertyType = $_POST['new-preferred-property-type'];
    $newBudget = $_POST['new-budget'];
    $newPreferredLocation = $_POST['new-preferred-location'];

    // SQL to update the client record
    $sql = "UPDATE client 
            SET FirstName = '$newFirstName', 
                LastName = '$newLastName', 
                ContactInformation = '$newContactInfo', 
                PreferredPropertyType = '$newPreferredPropertyType', 
                Budget = '$newBudget', 
                PreferredLocation = '$newPreferredLocation' 
            WHERE ClientID = '$clientIDToUpdate'";

    if ($conn->query($sql) === TRUE) {
        echo "Client record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Client</title>
</head>
<body>
    <h3>Client Updated</h3>
    <?php if (isset($message)) : ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>
    <a href="http://localhost/exam/clients">Go back</a>
</body>
</html>
