<?php
// Create connection to your database
$conn = new mysqli("localhost", "root", "", "final");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if Property ID is provided
    if (isset($_POST['property-id'])) {
        // Get the Property ID from the form
        $propertyid = $_POST['property-id'];
$address = $_POST['address'];
$propertytype = $_POST['property-type'];
$squarefootage = $_POST['square-footage'];
$bedrooms = $_POST['bedrooms'];
$bathrooms = $_POST['bathrooms'];
$status = $_POST['status'];
$agentid = $_POST['agent-id'];

        // Create an UPDATE SQL query
        $sql = "UPDATE property SET Address='$address',PropertyType='$propertytype',SquareFootage='$squarefootage',Bedrooms='$bedrooms',Bathrooms='$bathrooms',Status='$status',AgentID='$agentid' WHERE PropertyID = $propertyid";

        if ($conn->query($sql) === TRUE) {
            $message = "Property with Property ID $propertyID has been updated successfully.";
        } else {
            $message = "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        $message = "Property ID not provided.";
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Property</title>
</head>
<body>
    <h1>Update Property</h1>
    <?php if (isset($message)) : ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>
    <a href="update_property.html">Go back</a>
</body>
</html>
