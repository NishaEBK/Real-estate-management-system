<?php
// Create connection to your database
$conn = new mysqli("localhost", "root", "no", "final");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch existing properties from the database
$sql = "SELECT PropertyID, Address, PropertyType, SquareFootage, Bedrooms, Bathrooms, ListingPrice, Status, AgentID FROM property";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<br>";
    echo "<table>";
    echo "<thead><tr><th>---PropertyID---</th><th>---Address---</th><th>---Property Type---</th><th>---Square Footage---</th><th>---Bedrooms---</th><th>---Bathrooms---</th><th>---Listing Price---</th><th>---Status---</th><th>---AgentID---</th></tr></thead>";
    echo "<tbody>";
    
    while ($row = $result->fetch_assoc()) {
        echo "<br>";
        
        echo "<tr>";
        echo "<td>" . $row["PropertyID"] . "</td>";
        echo "<td>" . $row["Address"] . "</td>";
        echo "<td>" . $row["PropertyType"] . "</td>";
        echo "<td>" . $row["SquareFootage"] . "</td>";
        echo "<td>" . $row["Bedrooms"] . "</td>";
        echo "<td>" . $row["Bathrooms"] . "</td>";
        echo "<td>" . $row["ListingPrice"] . "</td>";
        echo "<td>" . $row["Status"] . "</td>";
        echo "<td>" . $row["AgentID"] . "</td>";
        echo "</tr>";
    }

    echo "</tbody>";
    echo "</table>";
} else {
    echo "No properties found.";
}

// Close the database connection
$conn->close();
?>


<!DOCTYPE html>
<html>
<head>
    <title>View Property</title>
</head>
<body>
    <?php if (isset($message)) : ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>
    <h3><u><a href="http://localhost/exam/properties.html">Go back</a></u></h3>
</body>
</html>