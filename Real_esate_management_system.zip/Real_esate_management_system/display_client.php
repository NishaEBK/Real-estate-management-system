<?php
// Create connection to your database
$conn = new mysqli("localhost", "root", "", "final");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch existing clients from the database
$sql = "SELECT * FROM client";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output table start
    echo "<table>
            <thead>
                <tr>
                    <th>ClientID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Contact Information</th>
                    <th>Preferred Property Type</th>
                    <th>Budget</th>
                    <th>Preferred Location</th>
                </tr>
            </thead>
            <tbody>";

    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["ClientID"] . "</td>";
        echo "<td>" . $row["FirstName"] . "</td>";
        echo "<td>" . $row["LastName"] . "</td>";
        echo "<td>" . $row["ContactInformation"] . "</td>";
        echo "<td>" . $row["PreferredPropertyType"] . "</td>";
        echo "<td>" . $row["Budget"] . "</td>";
        echo "<td>" . $row["PreferredLocation"] . "</td>";
        echo "</tr>";
    }

    // Output table end
    echo "</tbody></table>";
} else {
    echo "0 results";
}

// Close the database connection
$conn->close();
?>


<!DOCTYPE html>
<html>
<head>
    <title>View Property</title>
</head>
<body>
    <?php if (isset($message)) : ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>
    <h3><u><a href="http://localhost/exam/clients.html">Go back</a></u></h3>
</body>
</html>