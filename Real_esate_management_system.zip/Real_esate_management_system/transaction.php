<?php
// Create connection
$conn = new mysqli("localhost", "root", "no", "final");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collect data from the transaction form
$transactionID = $_POST["transaction-id"];
$propertyID = $_POST["property-id"];
$clientID = $_POST["client-id"];
$agentID = $_POST["agent-id"];
$transactionType = $_POST["transaction-type"];
$transactionDate = $_POST["transaction-date"];
$salePrice = $_POST["sale-price"];
$rentalPrice = $_POST["rental-price"];

// Insert the data into the database
$sql = "INSERT INTO transaction (TransactionID, PropertyID, ClientID, AgentID, TransactionType, TransactionDate, SalePrice, RentalPrice)
        VALUES ('$transactionID', '$propertyID', '$clientID', '$agentID', '$transactionType', '$transactionDate', '$salePrice', '$rentalPrice')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the connection
$conn->close();
?>
