<?php
// Create connection to your database
$conn = new mysqli("localhost", "root", "", "final");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if Property ID is provided
    if (isset($_POST['property-id'])) {
        // Get the Property ID from the form
        $propertyID = $_POST['property-id'];

        // Create a DELETE SQL query
        $sql = "DELETE FROM property WHERE PropertyID = $propertyID";

        if ($conn->query($sql) === TRUE) {
            $message = "Property with Property ID $propertyID has been deleted successfully.";
        } else {
            $message = "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        $message = "Property ID not provided.";
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Property</title>
</head>
<body>
    <h1>Delete Property</h1>
    <?php if (isset($message)) : ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>
    <a href="http://localhost/exam/properties">Go back</a>
</body>
</html>
