<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "no", "final");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch audit log entries
$sql = "SELECT * FROM ClientAudit";
$result = $conn->query($sql);

if (!$result) {
    die("Error: " . $conn->error); // Add this line to check for errors
}

if ($result->num_rows > 0) {
    // Output data of each row
    echo "<table border='1'><tr><th>AuditID</th><th>FirstName</th><th>LastName</th><th>Action</th><th>ActionTimestamp</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["AuditID"] . "</td><td>" . $row["FirstName"] . "</td><td>" . $row["LastName"] . "</td><td>" . $row["Action"] . "</td><td>" . $row["ActionTimestamp"] . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

// Close the database connection
$conn->close();
?>
