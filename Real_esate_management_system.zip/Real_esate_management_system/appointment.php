<?php
// Create connection
$conn = new mysqli("localhost", "root", "", "final");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the data from the form
$appointmentid = $_POST['appointment-id'];
$clientid = $_POST['client-id'];
$agentid = $_POST['agent-id'];
$propertyid = $_POST['property-id'];
$appointmentdatetime = $_POST['appointment-date-time'];
$appointmentstatus = $_POST['appointment-status'];

// Insert the data into the database
$sql = "INSERT INTO appointment (AppointmentID, ClientID, AgentID, PropertyID, AppointmentDateTime, Status)
VALUES ('$appointmentid', '$clientid', '$agentid', '$propertyid', '$appointmentdatetime', '$appointmentstatus')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the connection
$conn->close();
?>