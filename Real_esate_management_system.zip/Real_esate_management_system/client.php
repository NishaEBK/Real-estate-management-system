<?php
// Create connection
$conn = new mysqli("localhost", "root", "", "final");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the data from the form
$clientid = $_POST['client-id'];
$firstName = $_POST['first-name'];
$lastName = $_POST['last-name'];
$contactInfo = $_POST['contact-info'];
$preferredPropertyType = $_POST['preferred-property-type'];
$budget = $_POST['budget'];
$preferredLocation = $_POST['preferred-location'];

// Insert the data into the database
$sql = "INSERT INTO Client (ClientID, FirstName, LastName, ContactInformation, PreferredPropertyType, Budget, PreferredLocation)
VALUES ('$clientid', '$firstName', '$lastName', '$contactInfo', '$preferredPropertyType', '$budget', '$preferredLocation')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the connection
$conn->close();
?>