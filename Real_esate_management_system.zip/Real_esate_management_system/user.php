<?php
// Create connection
$conn = new mysqli("localhost", "root", "no", "final");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the data from the form
$userid = $_POST['user-id'];
$username = $_POST['username'];
$password = $_POST['password'];
$role = $_POST['role'];
$firstname = $_POST['first-name'];
$lastname = $_POST['last-name'];
$contactinfo = $_POST['contact-info'];



// Insert the data into the database
$sql = "INSERT INTO user (UserID, Username, PasswordHash, Role, FirstName, LastName,  ContactInformation)
VALUES ('$userid', '$username', '$password', '$role', '$firstname', '$lastname', '$contactinfo')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the connection
$conn->close();
?>