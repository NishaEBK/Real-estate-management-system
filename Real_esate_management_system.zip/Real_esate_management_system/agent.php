<?php
// Create connection
$conn = new mysqli("localhost", "root", "", "final");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the data from the form
    $agent_id = $_POST['agent-id'];
    $first_name = $_POST['first-name'];
     $last_name = $_POST['last-name'];
    $contact_info = $_POST['contact-info'];
    $license_number = $_POST['license-number'];
    $specialization = $_POST['specialization'];
    $user_id = $_POST['user-id'];


// Insert the data into the database
     $sql = "INSERT INTO agent (AgentID, FirstName, LastName, ContactInformation, LicenseNumber, Specialization, UserID)
     VALUES ('$agent_id', '$first_name', '$last_name', '$contact_info', '$license_number', '$specialization', '$user_id')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the connection
$conn->close();
?>