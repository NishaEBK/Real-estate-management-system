<?php
// Create connection to your database
$conn = new mysqli("localhost", "root", "", "final");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get client ID from the form
    $clientIDToDelete = $_POST['client-id-to-delete'];

    // SQL to delete the client record
    $sql = "DELETE FROM client WHERE ClientID = '$clientIDToDelete'";

    if ($conn->query($sql) === TRUE) {
        echo "Client record deleted successfully";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>


<!DOCTYPE html>
<html>
<head>
    <title>Delete client</title>
</head>
<body>
    <h1>Deleted client</h1>
    <?php if (isset($message)) : ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>
    <a href="http://localhost/exam/clients">Go back</a>
</body>
</html>