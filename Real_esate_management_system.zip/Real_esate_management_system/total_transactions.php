<?php
// Create connection to your database
$conn = new mysqli("localhost", "root", "", "final");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to get total transactions for each client
$sql = "SELECT C.FirstName, COUNT(T.TransactionID) AS TotalTransactions
        FROM Client C
        INNER JOIN Transaction T ON C.ClientID = T.ClientID
        GROUP BY C.FirstName";

// Execute the query
$result = $conn->query($sql);

// Check if there are results
if ($result->num_rows > 0) {
    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        echo "<h2>";
        echo "Client: " . $row["FirstName"] . " | Total Transactions: " . $row["TotalTransactions"] . "<br>";
        echo "</h2>";
        echo "<br>";
    }
} else {
    echo "No results found.";
}

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Triggers</title>
</head>
<body>
    <?php if (isset($message)) : ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>
    <h3><u><a href="http://localhost/exam/main.html">Click here to Go back</a></u></h3>
</body>
</html>