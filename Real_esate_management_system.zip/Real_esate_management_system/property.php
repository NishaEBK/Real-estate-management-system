<?php
// Create connection
$conn = new mysqli("localhost", "root", "no", "final");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the data from the form
$propertyid = $_POST['property-id'];
$address = $_POST['address'];
$propertytype = $_POST['property-type'];
$squarefootage = $_POST['square-footage'];
$bedrooms = $_POST['bedrooms'];
$bathrooms = $_POST['bathrooms'];
$listingprice = $_POST['listing-price'];
$status = $_POST['status'];
$agentid = $_POST['agent-id'];

// Insert the data into the database
$sql = "INSERT INTO property (PropertyID, Address, PropertyType, SquareFootage, Bedrooms, Bathrooms, ListingPrice, Status, AgentID)
VALUES ('$propertyid', '$address', '$propertytype', '$squarefootage', '$bedrooms', '$bathrooms', '$listingprice', '$status','$agentid')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Property</title>
</head>
<body>
    <?php if (isset($message)) : ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>
    <h3><u><a href="http://localhost/exam/properties.html">Go back</a></u></h3>
</body>
</html>